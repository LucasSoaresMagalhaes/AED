public class Elemento {
    public Cliente cli;
    public Elemento prox;
    public Elemento(Cliente clientezar){
        cli = clientezar;
        prox = null;
    }
}
