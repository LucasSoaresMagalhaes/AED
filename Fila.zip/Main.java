import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Fila fileira = new Fila();
        Scanner ler1 = new Scanner(System.in);

        for (int i = 0; i < 3; i++) {

            System.out.println("NOME DO CLIENTE");

            String NomeCliente = ler1.next();

            System.out.println("HORARIO CHEGADA");

            Double Chegada = ler1.nextDouble();

            Cliente cli = new Cliente(NomeCliente, Chegada);

            fileira.Enfileirar(cli);

        }
        fileira.imprimir();
        ler1.close();
    }
}