public class Fila {
    private Elemento Frente;
    private Elemento Traz;

    public Fila() {
        Frente = new Elemento(null);
        Traz = new Elemento(null);
    }

    public boolean FilaVazia() {
        return (Frente.prox == null);
    }

    public void Enfileirar(Cliente cli) {
        Elemento novo = new Elemento(cli);
        if (Frente.prox == null) {
            Frente.prox = novo;
        }
        Traz.prox = novo;
        Traz = novo;
    }

    public Cliente Desinfileirar() {
        Elemento aux = Frente.prox;
        Frente.prox = aux.prox;
        if (aux == Traz) {
            Traz = Frente;
        } else {
            aux.prox = null;
        }
        return aux.cli;
    }

    public Cliente obterPrimeiro() {
        return Frente.prox.cli;
    }

    public int numeroClientes() {
        int contador = 0;
        if (FilaVazia()) {
            return 0;
        } else {
            Elemento aux = Frente;
            while (aux.prox != null) {
                aux = aux.prox;
                contador++;
            }
            return contador;
        }
    }

    public void imprimir() {
        Elemento aux = Frente;
        while (aux.prox != null) {
            System.out.println("NOME DO CLIENTE: " + aux.prox.cli.nome);
            System.out.println("HORARIO DE CHEGADA: " + aux.prox.cli.horarioChegada);
            aux = aux.prox;
        }
    }

    public Fila dividir() {
        Elemento aux = Frente;
        Fila par = new Fila();

        while (aux.prox != null) {

            int contador = 1;

            if (contador % 2 == 0) {
                Elemento novo = new Elemento(aux.prox.cli);
                if (par.Frente.prox == null) {
                    par.Frente.prox = novo;
                }
                par.Traz.prox = novo;
                par.Traz = novo;
                Desinfileirar();
            }
            contador++;
            aux = aux.prox;
        }
        return par;
    }

    public boolean verificarExistencia(Cliente cli) {
        Elemento aux = Frente;
        while (aux.prox != null) {
            if (aux.prox.cli == cli) {
                return true;
            }
            aux = aux.prox;
        }
        return false;
    }

    public int obterNumeroClientesAFrente(String nome) {
        int contador = 0;
        Elemento aux = Frente;
        while (aux.prox != null) {
            if (aux.prox.cli.nome.equals(nome)) {
                return contador;
            } else {
                contador++;
                aux = aux.prox;
            }
        }
        return -1;
    }

    public Fila copiar() {
        Fila noavaFila = new Fila();
        Elemento aux = Frente;
        while (aux.prox != null) {
            noavaFila.Enfileirar(aux.prox.cli);
            aux = aux.prox;
        }
        return noavaFila;
    }

    public double obterTempoMediaEspera(double atual) {
        double media = 0, totalDeTempo = 0, contador = 0;
        Elemento aux = Frente;

        while (aux.prox != null) {

            totalDeTempo += aux.prox.cli.horarioChegada;
            aux = aux.prox;
            contador++;

        }

        media = totalDeTempo / contador;

        return media;
    }

    public int numeroClientesEsperando() {
        Elemento aux = Frente;
        int contador = 0;
        while (aux.prox != null) {
            if (aux.prox.cli.horarioChegada >= 15) {
                contador++;
            }
        }
        return contador;
    }

}
