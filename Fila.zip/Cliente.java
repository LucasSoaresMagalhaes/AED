public class Cliente {
    public String nome;
    public double horarioChegada;
    public Cliente (String nomeCliente, Double HorarioChegada){
        this.nome = nomeCliente;
        this.horarioChegada = HorarioChegada;
    }
}
